from django.urls import path
from . import views

urlpatterns = [
    path('info/', views.display)
    #url: http://127.0.0.1:8000/dashboard/info/
]