from django.db import models

# Create your models here.

# model classes for this app (for database)