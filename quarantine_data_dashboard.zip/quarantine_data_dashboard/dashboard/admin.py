from django.contrib import admin

# Register your models here.

#how the admin interface of app looks like
