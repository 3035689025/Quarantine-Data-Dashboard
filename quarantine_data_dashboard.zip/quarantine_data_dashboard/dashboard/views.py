from operator import truediv
from django.shortcuts import render
from django.http import HttpResponse

#for retreiving data
import json
import requests #installed in pipenv
from datetime import date, datetime, timedelta

# Create your views here.

# Request handler (called "action" in software dev.)
# request -> response 

def display(request):
    

    '''
    INITIALISATION
    '''
    count = 0
    has_data = False

    #loop until past the last 7 days / both data sets have data on that day
    while count < 8 and has_data == False:
        fetch_date = (datetime.today() - timedelta (count)).strftime('%d/%m/%Y')
        #testing: print(fetch_date)
        '''
        FOR DATA ABOUT CASES
        '''
        case_json_object = { 
            "resource": 'http://www.chp.gov.hk/files/misc/no_of_confines_by_types_in_quarantine_centres_eng.csv',
            "section": 1,
            "format": "json",
            "filters": [
                [1,"eq", [fetch_date]]  #only fetch data on that day
            ]
        }
        case_json_dump = json.dumps(case_json_object) # turn json_object into string for q
        case_resp = requests.get('https://api.data.gov.hk/v2/filter', params={'q': case_json_dump})
        case_code = case_resp.status_code # 200 = success
        case_result = case_resp.json() #turn into a list of dict.s

        '''
        FOR DATA ABOUT CENTRES
        '''
        centre_json_object = { 
            "resource": 'http://www.chp.gov.hk/files/misc/occupancy_of_quarantine_centres_eng.csv',
            "section": 1,
            "format": "json",
            "filters": [
                [1,"eq", [fetch_date]]  #only fetch data on that day
            ],
            "sorts": [
                [8,"desc"]  # decending order of no. of available units
            ]
        }
        centre_json_dump = json.dumps(centre_json_object) # turn json_object into string for q
        centre_resp = requests.get('https://api.data.gov.hk/v2/filter', params={'q': centre_json_dump})
        centre_code = centre_resp.status_code # 200 = success
        centre_result = centre_resp.json() #turn into a list of dict.s

        # Have data in both sets> stop loop
        if case_result and  centre_result and case_result[0]["As of date"] == centre_result[0]["As of date"]: #both have data
             has_data = True
        # No data in one data set > continue loop
        else:
            count = count + 1
        
    # data: case_result, case_code, centre_result, centre_code, has_data


    '''
    ORGANISE DATA TO ENTER INTO CONTEXT 
    '''
    #check if connected
    connected = False
    if case_code == 200 and centre_code == 200: #both connections successful
        connected = True

    # NO CONNECTION
    else:
        #render not connected
        context = {
        "connected": connected
        }
        return render(request, 'dashboard3.html', context)

    # check if data is from the past 7 days
    if has_data: #input data (only if there is data)
        # *0* date
        date = case_result[0]["As of date"]

        # *1* quarantine units occupied
        units_in_use = 0
        for centre in centre_result:
            units_in_use = units_in_use + centre["Current unit in use"]
        
        # *2* unoccupied quarantine units available
        units_available = 0
        for centre in centre_result:
            units_available = units_available + centre["Ready to be used (unit)"]
        
        # *3* centres 1,2,3 > centre_result[0],[1],[2]

        # *4* no of persons quarantined
        person_quarantined = 0
        for centre in centre_result:
            person_quarantined = person_quarantined + centre["Current person in use"]
        
        # *5* no of non-close contacts but quarantined
        non_close_contacts = case_result[0]["Current number of non-close contacts"]

        # *consistent?
        case_person_quarantined = case_result[0]["Current number of close contacts of confirmed cases"] + non_close_contacts
        if case_person_quarantined == person_quarantined:
            count_consistent = True
        else:
            count_consistent = False
    
    # NO DATA FOR LAST 7 DAYS
    else:
        #render no data 
        context = {
        "connected": connected,
        "has_data": has_data
        }
        return render(request, 'dashboard3.html', context)
    
    # ALL DATA FETCHED SUCESSFULLY
    #define context
    context = {
        "connected": connected,
        "has_data": has_data,
        "data" : {
            "date": date,
            "units_in_use": units_in_use,
            "units_available": units_available,
            "persons_quarantined": person_quarantined,
            "non_close_contacts": non_close_contacts,
            "count_consistent": count_consistent
        },
        "centres" :[
            {
                "name": centre_result[0]["Quarantine centres"],
                "units": centre_result[0]["Ready to be used (unit)"]
            },
            {
                "name": centre_result[1]["Quarantine centres"],
                "units": centre_result[1]["Ready to be used (unit)"]
            },
            {
                "name": centre_result[2]["Quarantine centres"],
                "units": centre_result[2]["Ready to be used (unit)"]
            }
        ]
    }
    return render(request, 'dashboard3.html', context)
