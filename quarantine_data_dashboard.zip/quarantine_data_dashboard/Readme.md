Name: Luk Chin Kiu
University number: 3035689025


All required functionality is implemented.

The name of root directory: COMP3297_individual_assignment

The ULR of project: https://sheltered-hamlet-64003.herokuapp.com/dashboard/info/
